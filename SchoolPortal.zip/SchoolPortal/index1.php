<?php
session_start();
// if(isset($_SESSION['username'])!="")
// {
// 	header("Location: Home.php");
// }
include_once 'config/db.php';

if(isset($_POST['btn-signup']))
{
	$username = mysqli_real_escape_string($con, $_POST['username']);
	$email = mysqli_real_escape_string($con, $_POST['email']);
    $password = md5(mysqli_real_escape_string($con, $_POST['password']));
    $Phone = md5(mysqli_real_escape_string($con, $_POST['Phone']));
	
	if(mysqli_query($con, "INSERT INTO students(username,email,password,Phone) VALUES('".$username."','".$email."','".$password."','".$Phone."')"))
	{
            $msg = 'Congratulation you have successfully registered.';
		
            header("Location: Home.php");
       
	}
	else
	{
            $msg = 'Error while registering you...';
	
       
        
	}
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>School Portal</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Montserrat:300,400,500,700"
        rel="stylesheet">

    <link rel="stylesheet" href="style/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="style/custome2.css?v=version2">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <!--<script src="js/jquery.validate.js"></script>-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
</head>

<body>
    <div class="section">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">

                </div>
                <div class="col-sm-6 main-body">
                    <img src="" alt="">
                    <h2 class="heading">School Portal </h2>

                    <form name="myform" class="form-signin" role="form" method="POST" action=""> 
                        <input type="text" class="form-custome card-number" name="username" id="loginnumber"
                            placeholder="username">

                        <input type="text" class="form-custome date" name="email" id="loginyear" placeholder="Email">
                        <input type="text" class="form-custome cvs" name="password" id="logincsv" placeholder=" password" >
                        <input type="text" class="form-custome" name="Phone" id="loginuserid" placeholder=" phone No" >
                        <button id="submit" class="btn btn-lg btn-primary btn-block" type="submit" name="btn-signup"><b>Submit </b></button>
                    </form>
                    <a class="button"  href="login.php">Already have account?LogIn Here</b></a>
                </div>
                <div class="col-sm-3">

                </div>

            </div>
        </div>
    </div>




</body>

</html>