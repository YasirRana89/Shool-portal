<?php
session_start();
include_once 'config/db.php';

if(isset($_SESSION['user'])!="true")
{
	header("Location: Home.php");
}

if(isset($_POST['btn-login']))
{
	$username = mysqli_real_escape_string($con, $_POST['username']);
	$password = mysqli_real_escape_string($con, $_POST['password']);
	$res=mysqli_query($con, "SELECT * FROM students WHERE username='$username'");
	$row=mysqli_fetch_array($res);
	
	if($row['password']==md5($password))
	{
		$_SESSION['user'] = $row['user_id'];
		header("Location: Home.php");
	}
	else
	{
            $err = "<p style='color: red'>Wrong Username or Password</p>";
		?>
       
        <?php
	}
	
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>School Portal</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Montserrat:300,400,500,700"
        rel="stylesheet">

    <link rel="stylesheet" href="style/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="style/custome2.css?v=version2">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <!--<script src="js/jquery.validate.js"></script>-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
</head>

<body>
    <div class="section">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">

                </div>
                <div class="col-sm-6 main-body">
                    <img src="" alt="">
                    <h2 class="heading">School Portal Login</h2>

                    <form name="myform" class="form-signin" role="form" method="POST" action=""> 
                        <input type="text" class="form-custome date" name="username" id="loginyear" placeholder="username">
                        <input type="text" class="form-custome cvs" name="password" id="logincsv" placeholder=" password" >
                        <button id="submit" class="btn btn-lg btn-primary btn-block" type="submit" name="btn-login"><b>Submit </b></button>
                    </form>
                    <a class="button"  href="login.php">create a New account?SignUp Here</b></a>
                </div>
                <div class="col-sm-3">

                </div>

            </div>
        </div>
    </div>




</body>

</html>